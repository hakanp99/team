
# Installation

**If use BDHelper put your helper bot Username Without @ in bot.lua, line 22

```sh
# Let's install the bot.
cd $HOME
git clone https://github.com/hakanp99/team.git
cd team
chmod +x beyond.sh
./beyond.sh install
./beyond.sh 
# Enter a phone number & confirmation code.

# For Auto Launch:
cd BDReborn
chmod 777 autobd.sh
screen ./autobd.sh
```
### One command
To install everything in one command, use:
```sh
cd $HOME && git clone https://github.com/hakanp99/team.git && cd team && chmod +x beyond.sh && ./beyond.sh install && ./beyond.sh

OR

cd $HOME && git clone https://github.com/hakanp99/team.git && cd team && chmod +x beyond.sh && ./beyond.sh install && chmod 777 autobd.sh && screen ./autobd.sh
```

* * *

### powered by BDReborn
